function renderProducts(products) {
  const productList = document.getElementById('product-list');

  const productsHTML = products
    .map(
      product =>
        `<div class="product col-lg-4 col-md-6 mb-4">
		<div class="card h-100">
			<a href="#"
				><img
					class="card-img-top"
					src="${product.image}"
					alt="${product.title}"
			/></a>
			<div class="card-body">
				<h4 class="card-title">
				    ${product.title}
				</h4>
				<h5 class="product-price">${formatMoney(product.price)} تومان</h5>
				<p class="card-text">
				    ${product.description}
				</p>
			</div>
			<div class="card-footer">
				<button onclick="updateCart(\'${product.title}\',\'${product.id}\',1,\'add\')" class="btn btn-light add-to-cart" data-product-id="${product.id}">
					افزودن به سبد خرید
				</button>
			</div>
		</div>
	</div>`
    )
    .join('');

  productList.innerHTML = productsHTML;
}

function formatMoney(amount, decimalCount = 0, decimal = '.', thousands = ',') {
  try {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

    const negativeSign = amount < 0 ? '-' : '';

    let i = parseInt(
      (amount = Math.abs(Number(amount) || 0).toFixed(decimalCount))
    ).toString();
    let j = i.length > 3 ? i.length % 3 : 0;

    return (
      negativeSign +
      (j ? i.substr(0, j) + thousands : '') +
      i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousands) +
      (decimalCount
        ? decimal +
          Math.abs(amount - i)
            .toFixed(decimalCount)
            .slice(2)
        : '')
    );
  } catch (e) {
    console.log(e);
  }
}

let productList = [];
window
  .fetch('http://localhost:3000/products')
  .then(res => res.json())
  .then(result => {
    productList = result;
    renderProducts(productList);
  });

let products = [];
window.addEventListener('load', () => {
  products = JSON.parse(localStorage.getItem("cart"));
  if (products != null) {
    products.forEach(product => {
      $('#cart-list').append(`
      <div class="cart">
      <div class="list-group-item d-flex justify-content-between align-items-center cart-item">
          <span>${product.title}</span>
          <div>
          <button class="btn inc-quantity" onclick="updateCart(\'${product.title}\',\'${product.id}\',${product.quantity},\'add\')" data-product-id="${product.id}">+</button>
          <span>${product.quantity}</span>
          <button class="btn dec-quantity" onclick="updateCart(\'${product.title}\',\'${product.id}\',${product.quantity},\'remove\')" data-product-id="${product.id}">-</button>
          </div>
      </div>
      </div>
      `)
    })
  }

})

  function updateCart(title,id,quantity,mode){
    let myProduct = {
      "title" : title,
      "id" : id,
      "quantity" : quantity
    }
    if(products == null)
    {
      products.push(myProduct);
      localStorage.setItem("cart", JSON.stringify(products));
    }
    else
    {
      if(mode == "add")
      {
        checkAndAdd(myProduct); 
      }
      else if(mode == "remove")
      {
        checkAndRemove(myProduct);
      }
    }
    function checkAndAdd(obj){
      for (let i = 0; i < products.length; i++) {
        if (products[i].id == obj.id) {
          products[i].quantity++;
          localStorage.setItem("cart", JSON.stringify(products));
          return;
        }
      }
      products.push(myProduct);
    }
    function checkAndRemove(obj){
      for (let i = 0; i < products.length; i++) {
        if (products[i].id == obj.id) {
          products[i].quantity--;
          if(products[i].quantity == 0)
          {
            products.splice(i, 1);
          }
          localStorage.setItem("cart", JSON.stringify(products));
          return;
        }
      }
    }
    $('#cart-list').empty();
    products.forEach(product => {
      $('#cart-list').append(`
      <div class="cart">
      <div class="list-group-item d-flex justify-content-between align-items-center cart-item">
          <span>${product.title}</span>
          <div>
          <button class="btn inc-quantity" onclick="updateCart(\'${product.title}\',\'${product.id}\',${product.quantity},\'add\')" data-product-id="${product.id}">+</button>
          <span>${product.quantity}</span>
          <button class="btn dec-quantity" onclick="updateCart(\'${product.title}\',\'${product.id}\',${product.quantity},\'remove\')" data-product-id="${product.id}">-</button>
          </div>
      </div>
      </div>
      `)
    })
  }

  